%used to estimate plate parameters (h,ro,c,alpha) using NC-RUS
%NC-RUS: non-contact resonant spectroscopy
%sample: 1-st measurement, with sample between transducers 
%calibration: 2-nd measurement, nothing in between transducers
clear all
addpath 'z:\Research\matlab\'

MainPath='d:\WinWord\LINAS\strUltrasonicsElesevier\Pyramids\matlab\Alberto\NitrocelluloseMembrane0.45um_h130um\';%+++R0.15MRayl
%pulse excitation:
SampleDir='TB1MHz1p20V100avg_sample\';GainS_dB=47;VTXS=20;FrontBlancS_us=240;EndBlancS_us=280;
CalibrDir='TB1MHz1p20V100avg_calibration\';GainC_dB=25;VTXC=20;FrontBlancC_us=240;EndBlancC_us=280;
hs=56e-6;cs=151;ros=1002;a0s=1801;ns=0;

% %chirp excitation:
% SampleDir='Ch700k1.4MHz50us10V100avg_sample\';GainS_dB=47;VTXS=10;FrontBlancS_us=240;EndBlancS_us=320;%-
% CalibrDir='Ch700k1.4MHz50us10V100avg_calibration\';GainC_dB=25;VTXC=10;FrontBlancC_us=240;EndBlancC_us=320;
% hs=59e-6;cs=159;ros=958;a0s=1891;ns=0;

%meadia into which sample is immersed, AIR below:
c1=343;ro1=1.225;

%allowed PSO fitting range:
Brange=1.5;

if contains(SampleDir,'Tb300kHz')|contains(SampleDir,'Ch150k')
    fmaxToPlot_MHz=0.7;
elseif contains(SampleDir,'Tb650kHz')|contains(SampleDir,'Ch350k')
    fmaxToPlot_MHz=1.5;
else
    fmaxToPlot_MHz=2.5;
end

%% Loading Data
fullPathS=[MainPath SampleDir];
fullPathC=[MainPath CalibrDir];
nn = strfind(fullPathS, '\');
conditionsTXT=fullPathS(nn(end-2)+1:nn(end)-1);
conditionsTXT=strrep(conditionsTXT, '\', '.');
conditionsTXT=strrep(conditionsTXT, '_', '-');
GenCodeNr = 1;
[~,~,NrOfXst,NrOfYst,Znr1,Znr2,fsampl,AvgSamplesNumber] = LoadVariables([fullPathS 'standard.var']);
DecimationCoeff=10;
Z1=1;
Z2=Znr2-Znr1+1;Z2=floor(Z2/DecimationCoeff)*DecimationCoeff;
AscanLength=Znr2-Znr1+1;

%load data:
MATdataFile='Data.mat';
if exist([fullPathS MATdataFile], 'file') == 2
     'MATLAB .dat file exists, loading Matlab data'
     %once converterd to mat data is available:
     load([fullPathS MATdataFile]);
else
    %first time:
    'MATLAB .dat file does not exist, loading raw data'
    us=LoadBINxyDecimateAvg([fullPathS 'CycADCgenCod1Ch1.bin'],1,1,AscanLength,Z1,Z2,DecimationCoeff,AvgSamplesNumber);
    SampleScaled=us/10^(GainS_dB/20)/VTXS;
    uc=LoadBINxyDecimateAvg([fullPathC 'CycADCgenCod1Ch1.bin'],1,1,AscanLength,Z1,Z2,DecimationCoeff,AvgSamplesNumber);
    CalibrScaled=uc/10^(GainC_dB/20)/VTXC;
    SigLen=round((Z2-Z1+1)/DecimationCoeff);
    fsampl=fsampl/DecimationCoeff;
    Z1=Z1/DecimationCoeff;
    Znr1=Znr1/DecimationCoeff;
    save([fullPathS MATdataFile],'us','uc','CalibrScaled','SampleScaled','SigLen','fsampl','Z1','Znr1','DecimationCoeff');
end

%% process

t_us=((0:(SigLen-1))+Z1+Znr1)/fsampl*1e6;
if EndBlancC_us>t_us(end), EndBlancC_us=t_us(end);end
if EndBlancS_us>t_us(end), EndBlancS_us=t_us(end);end

if FrontBlancC_us<=FrontBlancS_us
    t1_us=FrontBlancC_us;
else
    t1_us=FrontBlancS_us;
end
if EndBlancC_us>=EndBlancS_us
    t2_us=EndBlancC_us;
else
    t2_us=EndBlancS_us;
end

%Gate out:
FrontBlancS_samples=round((FrontBlancS_us-t_us(1))*1e-6*fsampl);
SampleScaled(1:FrontBlancS_samples)=0;
FrontBlancC_samples=round((FrontBlancC_us-t_us(1))*1e-6*fsampl);
CalibrScaled(1:FrontBlancC_samples)=0;
EndBlancS_samples=round((EndBlancS_us-t_us(1))*1e-6*fsampl);
SampleScaled(EndBlancS_samples:end)=0;
EndBlancC_samples=round((EndBlancC_us-t_us(1))*1e-6*fsampl);
CalibrScaled(EndBlancC_samples:end)=0;

F_MHz=((1:SigLen)-1)/SigLen*fsampl/1e6;
SpectrumCalibrScaled=fft(CalibrScaled);
SpectrumSampleScaled=fft(SampleScaled);
Transmission=SpectrumSampleScaled./SpectrumCalibrScaled;
Transmission_exp_dB=20*log10(abs(Transmission));
Transmission_exp_dB(1)=0;
Transmission_exp_deg=angle(Transmission)/pi*180;

figure(1)
plot(t_us,us,'r',t_us,uc,'k')
xlabel('t (us)');ylabel('Amp (au)'); axis tight; grid on;legend('Sampl','Calibr')
xlim([t1_us t2_us])

figure(2)
plot(F_MHz,20*log10(abs(SpectrumSampleScaled)),'k','LineWidth',2);
ylabel('Magnitude (dB)');ylim([-70 0])
grid on
title({['@ ' conditionsTXT];' ' })
xlabel('Frequency (MHz)')
axis tight
xlim([0.1,fmaxToPlot_MHz])

if exist('MyFontSize','var'), set(gca,'FontSize',MyFontSize);end;
if exist('MyTitleFontScale','var'),
    ax = gca;ax.TitleFontSizeMultiplier = MyTitleFontScale;
end

%% fit 1 layer model:
% search limits for PSO:
MyLB(1)=a0s/Brange; MyUB(1)=a0s*Brange;  % attenuation coefficient limits
MyLB(3)=ns/Brange; MyUB(3)=ns*Brange;    % exponentiation number of attenutions limits
MyLB(2)=cs/Brange; MyUB(2)=cs*Brange;    % Ultrasound velocity of layer limits 
MyLB(4)=ros/Brange; MyUB(4)=ros*Brange;  % Layer density limits 500/2000 karton
MyLB(5)=hs/Brange; MyUB(5)=hs*Brange;    % Layer thicknes limits 

'fitting...'
nr1=FrontBlancS_samples;nr2=EndBlancS_samples;
Fitmodel = @(Optimised_parameter)  TransmError_calc(Optimised_parameter, c1, ro1, fsampl, SampleScaled, CalibrScaled,nr1,nr2);
siz=600; %swarm size, recomended >100, otherwise might not converge

hybridopts = optimoptions('fmincon','OptimalityTolerance',1e-10);
options = optimoptions('particleswarm','SwarmSize',siz,'HybridFcn',{'fmincon',hybridopts});

parameter0 = particleswarm(Fitmodel,length(MyLB),MyLB,MyUB,options); % PSO optimiser

%can be uncommented for further optimisation:
% options = optimset('MaxFunEvals',10000000,'MaxIter', 1E7);
% parameter0 = fminsearch(Fitmodel,parameter0,options);

a0=round(parameter0(1)) % attenuation coefficient
n=parameter0(3)  % exponentiation number of attenutions
V_m_s=round(parameter0(2)) % Ultrasound velocity of layer
ro=round(parameter0(4))  % Layer density limits
h_fit=parameter0(5); % Layer thiknes limits
htot_um=round(h_fit*1e6)
Res_Freq_kHz=round(V_m_s/(2*h_fit)/1e3)
[num2str(h_fit*1e6) ' ' num2str(parameter0(2)) ' ' num2str(parameter0(4)) ' ' num2str(parameter0(1)) ' ' num2str(parameter0(3))]
Tranmission_model=resonant_spectroscopy_model_Transmission(parameter0,c1,ro1,fsampl,SigLen);
Sample_model=real(ifft(SpectrumCalibrScaled.*Tranmission_model));

RE_dB=10*log10(sum((Sample_model(nr1:nr2)-SampleScaled(nr1:nr2)).^2)./sum(SampleScaled(nr1:nr2).^2))

% %% save transmision:
% MATtransmissionFile='Transmission.mat';
% save([fullPathS MATtransmissionFile],'F_MHz','SpectrumCalibrScaled','SpectrumSampleScaled','Transmission');

%% plot

nn=find(F_MHz>=fmaxToPlot_MHz);nfmaxOrig=nn(1);
figure(6)
plot(F_MHz,Transmission_exp_dB,'k',F_MHz,20*log10(abs(Tranmission_model)),'m','lineWidth',2)
xlabel('f (MHz)');ylabel('T (out/in, dB)'); axis tight; grid on;title(conditionsTXT)
% xlim([0.5*f0,1.5*f0]/1e6)
legend('TTexp','TTfit','Location','Best')
xlim([0.1,fmaxToPlot_MHz])
ylim([min(Transmission_exp_dB(1:nfmaxOrig)) max(Transmission_exp_dB(1:nfmaxOrig))])

figure(7)
plot(F_MHz,Transmission_exp_deg,'k',F_MHz,angle(Tranmission_model)/pi*180,'m','lineWidth',2)
xlabel('f (MHz)');ylabel('T (out/in, deg)'); axis tight; grid on;
% title(TitleText1)
title(['h=' num2str(htot_um) 'um,V=' num2str(V_m_s) 'm/s,ro=' num2str(ro) 'kg/m^3,a0=' num2str(a0) 'Np/m,n=' num2str(n) ',F_{rez}=' num2str(Res_Freq_kHz/1000) 'MHz'])
legend('TTexp','TTfit','Location','Best')
xlim([0.1,fmaxToPlot_MHz])

figure(8)
plot(t_us,SampleScaled,'b',t_us,Sample_model,'r',t_us(EndBlancS_samples),SampleScaled(EndBlancS_samples),'ro')
xlabel('t (us)');ylabel('H RX (Pa)'); axis tight; grid on;legend('Orig','Fit','Location','Best')
xlim([FrontBlancS_us EndBlancS_us])
% title(['a0=' num2str(a0) ',n=' num2str(n) ',V=' num2str(V_m_s) 'm/s,ro=' num2str(ro) 'kg/m^3,h=' num2str(htot_um) 'um,F_{rez}=' num2str(Res_Freq_kHz/1000) 'MHz'])
title(['RE=' num2str(RE_dB,'%.1f') 'dB, Z=' num2str(V_m_s*ro/1e6,'%.2f') 'MRayl'])