function [Tranmission_model]=resonant_spectroscopy_model_Transmission(parameter,c1,ro1,fsampl,nfft)
%% universal fitting, suitable both for 1 and 2 layers:
freq0=1.5e6;
if length(parameter)>6
    DoubleLayer=true;
    alfa0_1=parameter(1);
    V_sample_1=parameter(2);
    n_1=parameter(3);
    roSampl_1=parameter(4);
    h=parameter(5);%total thickness!!!!
    alfa0_2=parameter(6);
    V_sample_2=parameter(7);
    n_2=parameter(8);
    roSampl_2=parameter(9);
    hSampl_2=parameter(10);
    hSampl_1=h-hSampl_2;
else
    DoubleLayer=false;
    alfa0=parameter(1);
    V_sample=parameter(2);
    n=parameter(3);
    roSampl=parameter(4);
    hSampl=parameter(5);
    % Gain=Get_parameter(6);
end


Halfnfft=floor(nfft/2);
nr=(1:Halfnfft+1)-1;
freq(1:Halfnfft+1)=double(fsampl/nfft*nr*1.0e0);
nr=(Halfnfft+2:nfft)-(nfft+1);
freq(Halfnfft+2:nfft)=double(fsampl/nfft*nr*1.0e0);
% figure(1)
% plot(abs(freq)/freq0)
Z1=c1*ro1; % air impedance
if DoubleLayer
    alf_1=alfa0_1*(abs(freq)/freq0).^n_1;
    alf_2=alfa0_2*(abs(freq)/freq0).^n_2;
    Csampl_1=V_sample_1;
    Csampl_2=V_sample_2;
    k1=2*pi*(freq)./Csampl_1+1i*alf_1; %why +i?
    k2=2*pi*(freq)./Csampl_2+1i*alf_2; %why +i?
    Vsampl_1=2*pi*(freq)./real(k1); %was real
    Vsampl_2=2*pi*(freq)./real(k2); %was real
    % veloc=C; %pure real, no dispersion !!!
    Zsampl_1=Vsampl_1*roSampl_1;
    Zsampl_2=Vsampl_2*roSampl_2;
    m12=Zsampl_1./Zsampl_2;ma1=Z1./Zsampl_1;ma2=Z1./Zsampl_2;
    %% transmision fuction
    T=-2./((2.*cos(k1*hSampl_1).*cos(k2*hSampl_2)-(m12+1./m12).*sin(k1*hSampl_1).*sin(k2*hSampl_2))+...
        1i*((ma1+1./ma1).*sin(k1*hSampl_1).*cos(k2*hSampl_2)+(ma2+1./ma2).*cos(k1*hSampl_1).*sin(k2*hSampl_2)));% from "Research on the Transmission Char.. of Air-Coupled US in Double-Layered..."
    T(1)=0;T(Halfnfft+1)=0;
    Tranmission_model=-(T).*exp(1i*2*pi*freq*(h/c1));
else
    alf=alfa0*(abs(freq)/freq0).^n;
    C=V_sample;
    k=2*pi*(freq)./C+1i*alf; %why +i?
    veloc=2*pi*(freq)./real(k); %was real
    % veloc=C; %pure real, no dispersion !!!
    Zsampl=veloc*roSampl;
    %% transmision fuction
    % T=(-2*Z1*Zsampl)./(2*Z1*Zsampl.*cos(k*h)+1i*(Z1^2+Zsampl.^2).*sin(k*h));%Tomas?
    % m=Z1./Zsampl;T=-2./(2*cos(k*h)+1i*(m+1./m).*sin(k*h));%same as above, Tomas, "Ultrasound Attenuation in Cylindrical Micro-Pores" add(-2)
    T=(4*Z1*Zsampl)./(-(Z1-Zsampl).^2.*exp(1i*k*hSampl)+(Z1+Zsampl).^2.*exp(-1i*k*hSampl));%Bershkovkich (2.4.14)
    % T=(4*Z1*Zsampl)./((Z1-Zsampl).*(Zsampl-Z1).*exp(1i*k*h)+(Z1+Zsampl).^2.*exp(-1i*k*h));%G.T.Clement,conj(T) required,used for better convergence, speed++

    %these are Bershkovkich (2.4.13)
    % T=(1+((-Z1.^2+Zsampl.^2).*exp(-(2*i).*k*h)+(Z1.^2-Zsampl.^2))./((Z1+Zsampl).^2.*exp((2*i)*k*h)-(Z1-Zsampl).^2))./(cos(k*h)-i*Zsampl.*sin(k*h)/Z1);%bad?
    % T=(1+((-Z1.^2+Zsampl.^2).*exp(-(2*i).*k*h)+(Z1.^2-Zsampl.^2))./((Z1+Zsampl).^2.*exp((2*i).*k*h)-(Z1-Zsampl).^2))./(cos(k*h)-i*Zsampl.*sin(k*h/Z1));%bad?

    T(1)=0;T(Halfnfft+1)=0;
    %  Tranmission_model=Ref_fft.*conj(T).*exp(i*2*pi*freq*(h/c1)); %%%% Measured''
    Tranmission_model=conj(T).*exp(1i*2*pi*freq*(hSampl/c1)); %%%% Measured'' why conj(T)?
    % Tranmission_model=Gain*Tranmission_model;
end