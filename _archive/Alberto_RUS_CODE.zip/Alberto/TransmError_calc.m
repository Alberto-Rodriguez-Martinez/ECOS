function [Error]=TransmError_calcC1C2(Get_parameter,c1, ro1, fsampl,Sample_exp,Ref_exp,nr1,nr2)

AscanLength=length(Sample_exp);

Tranmission_model=resonant_spectroscopy_model_Transmission(Get_parameter,c1, ro1, fsampl,AscanLength);

Ref_fft=fft(Ref_exp);

% %uncomment for f-domain fitting
% sample_fft=fft(Sample_exp); % Fourier Transform of Data
% ref_fft=fft(Ref_exp); %Fourier Transform of Reference
% Tranmission_exp=sample_fft./ref_fft;  

 %% Reminder Energy Gated
Sample_model=real(ifft(Ref_fft.*Tranmission_model));
% Sample_model=real(ifft(Ref_fft.*Tranmission_model.*Tranmission_model.*Tranmission_model));

Error=sum(abs(Sample_model-Sample_exp).^2)./sum(abs(Sample_exp).^2); %calc eror of sample signal in time

Error=10*log10(sum(abs(Sample_model(nr1:nr2)-Sample_exp(nr1:nr2)).^2)./sum(abs(Sample_exp(nr1:nr2)).^2)); %calc eror of sample signal in time +++
% Error=sum(abs(Sample_model(nr1:nr2)-Sample_exp(nr1:nr2)).^2); %calc eror of sample signal in time ++++

% % F domain working good, Re=Im: worse RE than time:
% MyFmask=abs(Ref_fft);MMM=max(MyFmask);nnn=find(MyFmask>=MMM/1000);
% ErrorR=sum((real(Tranmission_model(nnn))-real(Tranmission_exp(nnn))).^2); 
% ErrorI=sum((imag(Tranmission_model(nnn))-imag(Tranmission_exp(nnn))).^2);
% Error=ErrorR+ErrorI; %calc eror of model in frequency domain??

% %Mgn+Phase: more worse RE
% MyFmask=abs(Ref_fft);MMM=max(MyFmask);nnn=find(MyFmask>=MMM/1000);
% ErrorA=sum((abs(Tranmission_model(nnn))-abs(Tranmission_exp(nnn))).^2)/std(abs(Tranmission_exp(nnn)).^2); %max/std
% ErrorP=sum((angle(Tranmission_model(nnn))-angle(Tranmission_exp(nnn))).^2)/std(angle(Tranmission_exp(nnn)).^2); 
% Error=ErrorA+ErrorP; %calc eror of model in frequency domain?? 5*ErrorP
% % Error=ErrorA;

%  if Error==Inf, Error=1e200; end;
% if isnan(Error), Error=1e200; end;
% if Get_parameter(3)<0, Error=Error+abs(Get_parameter(3));%punishment for negative n

end